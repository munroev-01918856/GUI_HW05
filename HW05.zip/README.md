# GUI_HW05

repo:https://github.com/munroev-01918856/GUI_HW05
page:https://munroev-01918856.github.io/GUI_HW05/

## Problems
Everything in rubric is fully implemented, the only parts not implemented are the tile & board images. Instead tiles are set as in-block but just rest against the webpage backgound below the board. The board is a set of 15 html elements with double word & letter tiles that are droppable components (the lack of board image was approved by TA Tim Trong).

None of the extra credit was implemented.

## Tiles
Tile pool gets the letters from provided JSON which is read by AJAX and then is iterated through to create an array with all the tiles & their values 
(source: https://github.com/ykanane/Scrabble/blob/master/js/add-content.js). At the beginning of every game & round tiles are grabbed from 'bag' by using random number generator

In rac
